# Real-EState-Website
Real Estate website for buying and selling houses made using django and bootstrap4. Any user can register and make a listing for selling a property

developed using python

Made by Gautam Patel
